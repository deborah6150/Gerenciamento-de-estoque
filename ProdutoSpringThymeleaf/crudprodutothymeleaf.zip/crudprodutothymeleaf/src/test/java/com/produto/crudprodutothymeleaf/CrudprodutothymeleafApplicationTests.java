package com.produto.crudprodutothymeleaf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudprodutothymeleafApplicationTests {

	@Test
	void contextLoads() {
	}

}
